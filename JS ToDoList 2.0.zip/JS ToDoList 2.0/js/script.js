const toDoInput = document.querySelector(".todo-input");
const todoButton = document.querySelector(".todo-button");
const toDoList = document.querySelector(".todo-list");


todoButton.addEventListener("click", addToDo);
toDoList.addEventListener("click", deleteCheck);



function addToDo(event) {
    //prevent form from submiting
    event.preventDefault();
    //ToDoDiv
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    //Create <Li>
    const todoLi = document.createElement("li");
    todoLi.innerText = toDoInput.value
    todoLi.classList.add("todo-item");
    todoDiv.appendChild(todoLi);
    //CheckMark btn
    const complete = document.createElement("button");
    complete.innerHTML = '<i class = "fas fa-check"> </i>'
    complete.classList.add("complete");
    todoDiv.appendChild(complete);
    //Trash btn
    const trash = document.createElement("button");
    trash.innerHTML = '<i class= "fas fa-trash"></i>'
    trash.classList.add("trash");
    todoDiv.appendChild(trash);
    //Append to list
    toDoList.appendChild(todoDiv);
    //clear input value
    toDoInput.value = "";

}
function deleteCheck(event){
    const item = event.target;
    //Delete
    if(item.classList[0] === "trash"){
        const todo = item.parentElement;
        todo.remove();
    }
    //Check
    if(item.classList[0] === "complete"){
        const todo = item.parentElement;
        todo.classList.toggle("complete");
    
  }
}
 